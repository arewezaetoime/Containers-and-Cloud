docker build -t resellerapp .

docker-compose up -d