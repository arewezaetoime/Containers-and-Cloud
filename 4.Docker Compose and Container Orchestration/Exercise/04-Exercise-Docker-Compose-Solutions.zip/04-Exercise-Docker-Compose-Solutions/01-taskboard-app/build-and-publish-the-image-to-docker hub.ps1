docker build . -f ./TaskBoard.WebApp/Dockerfile -t udarensamolet/taskboard_app

docker images

docker login

docker push udarensamolet/taskboard_app